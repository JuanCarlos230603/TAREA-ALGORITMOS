/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package promedio;

/**
 *
 * @author Juan Carlos
 */
import java.util.Scanner;

public class Promedio {
    public static void main(String[] args) {
        // Pedir al usuario que ingrese tres números
        try ( // Crear un objeto Scanner para leer la entrada del usuario
                Scanner scanner = new Scanner(System.in)) {
            // Pedir al usuario que ingrese tres números
            System.out.print("Ingrese el primer número: ");
            double num1 = scanner.nextDouble();
            System.out.print("Ingrese el segundo número: ");
            double num2 = scanner.nextDouble();
            System.out.print("Ingrese el tercer número: ");
            double num3 = scanner.nextDouble();
            // Calcular el promedio
            double promedio = (num1 + num2 + num3) / 3;
            // Mostrar el resultado
            System.out.println("El promedio de los tres números es: " + promedio);
            // Cerrar el scanner
        }
    }
}

