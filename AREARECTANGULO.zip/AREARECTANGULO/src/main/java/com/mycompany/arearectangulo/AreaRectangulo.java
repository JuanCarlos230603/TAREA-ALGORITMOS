/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arearectangulo;

/**
 *
 * @author Juan Carlos
 */import java.util.Scanner;

public class AreaRectangulo {
    public static void main(String[] args) {
        // Pedir al usuario que ingrese la base y la altura del rectángulo
        try ( // Crear un objeto Scanner para leer la entrada del usuario
                Scanner scanner = new Scanner(System.in)) {
            // Pedir al usuario que ingrese la base y la altura del rectángulo
            System.out.print("Ingrese la base del rectángulo: ");
            double base = scanner.nextDouble();
            System.out.print("Ingrese la altura del rectángulo: ");
            double altura = scanner.nextDouble();
            // Calcular el área del rectángulo
            double area = base * altura;
            // Mostrar el resultado
            System.out.println("El área del rectángulo es: " + area);
            // Cerrar el scanner
        }
    }
}

