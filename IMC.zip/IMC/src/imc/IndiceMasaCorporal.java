/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package imc;

/**
 *
 * @author Juan Carlos
 */
import java.util.Scanner;

public class IndiceMasaCorporal {
    public static void main(String[] args) {
        // Pedir al usuario que ingrese su peso en kilogramos
        try ( // Crear un objeto Scanner para leer la entrada del usuario
                Scanner scanner = new Scanner(System.in)) {
            // Pedir al usuario que ingrese su peso en kilogramos
            System.out.print("Ingrese su peso en kilogramos: ");
            double peso = scanner.nextDouble();
            // Pedir al usuario que ingrese su altura en metros
            System.out.print("Ingrese su altura en metros: ");
            double altura = scanner.nextDouble();
            // Calcular el Índice de Masa Corporal (IMC)
            double imc = peso / (altura * altura);
            // Mostrar el resultado
            System.out.println("Su Índice de Masa Corporal (IMC) es: " + imc);
            // Cerrar el scanner
        }
    }
}

